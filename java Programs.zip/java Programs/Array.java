public class Array 
{
public static void main(String[] args) {
int a[];
int[] a1;
int []a2;
float b[];
a=new int[5];
b=new float[2];

a[0] = 10;
a[1] = 15;
a[2] = 12;
a[3] = 15;
a[4]=22;
System.out.println("Element at 0 :"+a[0]);
System.out.println("Element at 1 :"+a[1]);
System.out.println("Element at 2 :"+a[2]);
System.out.println("Element at 3 :"+a[3]);
System.out.println("Element at 4 :"+a[4]);
}
}