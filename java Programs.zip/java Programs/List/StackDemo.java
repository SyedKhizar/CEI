import java.util.*;
public class StackDemo {

    public static void main(String[] args) {
        Stack s1=new Stack();

        s1.add(1);
        s1.add("Khizar");
        s1.add(true);
        s1.add(true);
        s1.push("Akram");
        s1.push(null);

        System.out.println(s1);

        s1.pop();

        System.out.println(s1);

        System.out.println("Size of Stack is :"+s1.size());

        System.out.println("element at index position 3 is "+s1.get(3));

        s1.remove("Akram");

        System.out.println(s1);

    }
   
}