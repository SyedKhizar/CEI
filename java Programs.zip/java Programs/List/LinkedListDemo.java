import java.util.*;
public class LinkedListDemo
{
    public static void main(String[] args) {
       
        LinkedList l1=new LinkedList();

        l1.add(1);
        l1.add("Khizar");
        l1.add('A');
        l1.add(true);
        l1.add('a');
        l1.add(1);
        l1.add(null);


        System.out.println("Size of Linked List :"+l1.size());

        System.out.println(l1);

        System.out.println("First Element in Linked List l1 is "+l1.getFirst());
        System.out.println("Last Element in Linked List l1 is "+l1.getLast());


        l1.addFirst("Akram");
        l1.addLast("Syed");

        System.out.println(l1);

        System.out.println("First Element in Linked List l1 is "+l1.getFirst());
        System.out.println("Last Element in Linked List l1 is "+l1.getLast());

        l1.removeFirst();
        l1.removeLast();

        System.out.println(l1);

        System.out.println("First Element in Linked List l1 is "+l1.getFirst());
        System.out.println("Last Element in Linked List l1 is "+l1.getLast());



        LinkedList l2=new LinkedList();

        for(int i=1;i<=5;i++)
        {
            l2.add(i);
        }
        System.out.println("**************************************************");
        System.out.println(l2);


    }
}