import java.util.*;
public class ArrayListDemo
{
    public static void main(String[] args) {

        ArrayList al1=new ArrayList();

        al1.add(1);
        al1.add("Khizar");
        al1.add(40.444);
        al1.add('C');
        al1.add(true);
        al1.add(1);
        al1.add(null);

        System.out.println(al1);

        System.out.println("Total Objects inside List are :"+al1.size());


        al1.remove("Khizar");

        System.out.println(al1);

        System.out.println("Element at Index Position 4 is :"+al1.get(4));
        System.out.println("Element at Index Position 5 is :"+al1.get(5));

        al1.add(2,"Syed");

        System.out.println(al1);

        al1.set(1,10.234);

        System.out.println(al1);

        // al1.clear();

        // System.out.println(al1);


        ArrayList al2=new ArrayList();
        for(int i=1;i<=5;i++)
        {
            al2.add(i);
        }
        System.out.println("**************************************************");
        System.out.println(al2);


       
    }
}