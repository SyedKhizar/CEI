import java.util.*;
public class VectorDemo {
    public static void main(String[] args) {
        Vector v1=new Vector();

        v1.add(1);
        v1.add(true);
        v1.add(null);
        v1.add("Prudhvi");
        v1.add('A');
        v1.add(1);
        v1.addElement("Rajeev");

        System.out.println(v1);
        System.out.println("Size of Vector Object is :"+v1.size());

        System.out.println("Element At Index Position 2 is "+v1.get(2));

        v1.remove(1);

        v1.removeElementAt(4);

        System.out.println(v1);


        Vector v2=new Vector();

        for(int i=1;i<=10;i++)
        {
            v2.addElement(i);
        }

        System.out.println(v2);
       
        System.out.println("Retrieving elements of Vector one by one using for -loop");

        for(int i=0;i<v2.size();i++)
        {
           
           Integer i1=(Integer)v2.get(i);

           if(i1%2!=0)
           {
               System.out.println(i1);
           }
           
        }


    }
}