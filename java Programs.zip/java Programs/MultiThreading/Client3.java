public class Client3 {
    public static void main(String[] args) {
       
BoyFreindThread t1=new BoyFreindThread();
t1.start();



    }
}