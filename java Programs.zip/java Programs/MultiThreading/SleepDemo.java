import java.util.*;
class SleepDemo
{
    public static void main(String[] args) {
   
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter Username:");
        String username=sc.next();
        System.out.print("Enter Password:");
        String password=sc.next();

        System.out.println("Validating User ,Please Wait");
            try {
                Thread.sleep(5000);
            } catch (Exception e) {
                //TODO: handle exception
                System.out.println(e);
                }
        if(username.equals("admin") && password.equals("admin"))
        {
           
            System.out.println("Login Succees");
        }
        else
        {
            System.out.println("Login Failed");
        }


    }
}