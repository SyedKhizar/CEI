public class Client5 {
    public static void main(String[] args) {

        MyThread1 m1=new MyThread1();

        m1.start();
       

        System.out.println("Main Thread Priority :"+Thread.currentThread().getPriority());
        for (int i = 1; i<=5; i++) {
            System.out.println("Main Thread :"+i);
        }
    }
}