public class BookMovieThread extends Thread
{
    public void run()
    {
        DecideMovieThread dmt=new DecideMovieThread();
        dmt.start();
        try
        {
            dmt.join();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
       
        System.out.println("Book Movie Thread");

       
    }
}