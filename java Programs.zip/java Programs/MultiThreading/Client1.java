public class Client1 {

    public static void main(String[] args) {
       
        MyThread m1=new MyThread();//A New Thread Object is Created

        m1.start();

    }
   
}