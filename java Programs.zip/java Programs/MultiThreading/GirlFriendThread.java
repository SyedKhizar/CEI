public class GirlFriendThread extends Thread
{

    public void run()
    {
        for(int i=1;i<=10;i++)
        {
            try {
                Thread.sleep(3000);
            } catch (Exception e) {
                //TODO: handle exception
                System.out.println(e);
            }
           
                System.out.println("GirlFriend Thread is Executing");
           
        }
       
    }
   
}