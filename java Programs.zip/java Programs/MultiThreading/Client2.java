public class Client2 {

    public static void main(String[] args) {
       
        BookMovieThread wmt=new BookMovieThread();

        wmt.start();

        try {
            wmt.join();
        } catch (Exception e) {
            //TODO: handle exception
            System.out.println(e);
        }
       

        System.out.println("Watch Ticket Thread");

    }
   
}