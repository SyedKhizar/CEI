public class BoyFreindThread extends Thread{

    public void run()
    {
         GirlFriendThread t2=new GirlFriendThread();
        t2.start();

        try {
            join(10000);
        } catch (Exception e) {
            //TODO: handle exception
            System.out.println(e);
        }
        for(int i=0;i<=10;i++)
        {
            System.out.println("BoyFriend Thread is Waiting For Girl Firend Thread");
            System.out.println("BoyFriend Thread is Executing");
        }

       
       
     
    }
   
}
