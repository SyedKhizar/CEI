public class DecideMovieThread extends Thread{

    public void run()
    {
        System.out.println("Decide Movie Thread");
    }
   
}