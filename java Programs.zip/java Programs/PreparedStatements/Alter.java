package com.khizar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Alter  {

public static void main(String[] args)
{


Connection con=null;
PreparedStatement ps=null;

String url="jdbc:mysql://localhost:3306/shop";
String user="root";
String password="root";

String alterTableQuery="alter table employees add column(phone varchar(100))";



try {

con=DriverManager.getConnection(url, user, password);
ps=con.prepareStatement(alterTableQuery);

if(con!=null && ps!=null)
{

int result=ps.executeUpdate();

if(result==0)
{
System.out.println("Table Altered Successfully");
}
else
{
System.out.println("Problem with Table Alteration");
}

}
else
{
System.out.println("Problem with database or PreparedStatement");
}

}

catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}

}