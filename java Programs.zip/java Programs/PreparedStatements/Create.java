package com.khizar;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
public class Create {
public static void main(String[] args) {
Connection con=null;
String url="jdbc:mysql://localhost:3306/shop";
String user="root";
String password="root";
PreparedStatement ps=null;
String createTableQuery="create table employees(eid int primary key,ename varchar(100),ecity varchar(100),email varchar(100))";
try {
con=DriverManager.getConnection(url, user, password);
ps= con.prepareStatement(createTableQuery);
if(con!=null && ps!=null)
{
int result =ps.executeUpdate();

if(result==0)
{
System.out.println("Table Created Successfully");
}else
{
System.out.println("Problem With Table Creation");
}
}
else
{
System.out.println("Problem with database or PreparedStatement");
}
}catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}

}
}