package com.khizar;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class PreparedStatementSelect {

public static void main(String[] args) {

String url=null;
String username=null;
String password=null;

Properties p=new Properties();
FileInputStream fis=null;


Connection con=null;
PreparedStatement ps=null;
String selectQuery="select * from googlepay";
ResultSet rs=null;

try {

fis=new FileInputStream("src//com/khizar/dbdetails.properties");
p.load(fis);

url=p.getProperty("url");
username=p.getProperty("username");
password=p.getProperty("password");


con=DriverManager.getConnection(url, username, password);


if(con!=null)
{
System.out.println("Connection Established Successfully");
ps=con.prepareStatement(selectQuery);
rs=ps.executeQuery();

while(rs.next())
{
int acno=rs.getInt(1);
String acname=rs.getString(2);
float balance=rs.getFloat(3);
String city=rs.getString(4);

System.out.println("Accno : "+acno);
System.out.println("Account Name : "+acno);
System.out.println("Balance : "+balance);
System.out.println("City : "+city);

System.out.println("*******************************");

}
}
else
{
System.err.println("Connection Not Esatblished");
}


}
catch (Exception e)
{

}

}

}