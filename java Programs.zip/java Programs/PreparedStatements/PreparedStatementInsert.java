package com.khizar;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;
import java.util.Scanner;
public class PreparedStatementInsert {

public static void main(String[] args) {

String url=null;
String username=null;
String password=null;

Properties p=new Properties();
FileInputStream fis=null;


Connection con=null;
PreparedStatement ps=null;
String insertQuery="insert into googlepay values (?,?,?,?)";
Scanner sc=new Scanner(System.in);

System.out.print("Enter Account no :");
int acno=sc.nextInt();

System.out.print("Enter Account Name :");
String acname=sc.next();

System.out.print("Enter Balance :");
Float balance=sc.nextFloat();

System.out.print("Enter Customer City :");
String city=sc.next();

try {

fis=new FileInputStream("src//com/khizar/dbdetails.properties");
p.load(fis);

url=p.getProperty("url");
username=p.getProperty("username");
password=p.getProperty("password");


con=DriverManager.getConnection(url, username, password);


if(con!=null)
{
System.out.println("Connection Established Successfully");
ps=con.prepareStatement(insertQuery);
ps.setInt(1,acno);
ps.setString(2,acname);
ps.setFloat(3,balance);
ps.setString(4,city);

int result=ps.executeUpdate();

if(result==1)
{
System.out.println(result+ " record inserted successfully in table googlepay");
}
else
{
System.out.println("Failed to insert Record ");
}
}
else
{
System.err.println("Connection Not Esatblished");
}


}
catch (Exception e)
{

}

}

}