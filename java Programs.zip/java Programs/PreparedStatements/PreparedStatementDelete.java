package com.khizar;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;
import java.util.Scanner;

public class PreparedStatementDelete {

public static void main(String[] args) {

String url=null;
String username=null;
String password=null;

Properties p=new Properties();
FileInputStream fis=null;


Connection con=null;
PreparedStatement ps=null;
String deleteQuery="delete from googlepay where acno=?";
Scanner sc=new Scanner(System.in);

System.out.print("Enter Account no to delete:");
int acno=sc.nextInt();


try {

fis=new FileInputStream("src//com/khizar/dbdetails.properties");
p.load(fis);

url=p.getProperty("url");
username=p.getProperty("username");
password=p.getProperty("password");


con=DriverManager.getConnection(url, username, password);


if(con!=null)
{
System.out.println("Connection Established Successfully");
ps=con.prepareStatement(deleteQuery);
ps.setInt(1,acno);

int result=ps.executeUpdate();

if(result==1)
{
System.out.println(result+ " record deleted successfully in table googlepay");
}
else
{
System.out.println("Failed to delete Record ");
}
}
else
{
System.err.println("Connection Not Esatblished");
}


}
catch (Exception e)
{

}

}

}