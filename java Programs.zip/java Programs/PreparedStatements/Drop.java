package com.khizar;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Drop  {

public static void main(String[] args) {
Connection con=null;
PreparedStatement ps=null;

String url="jdbc:mysql://localhost:3306/shop";
String user="root";
String password="root";

Scanner sc=new Scanner(System.in);

System.out.print("Enter Table to Drop:");
String table_name=sc.next();

String dropTableQuery="drop table "+table_name;



try {

con=DriverManager.getConnection(url, user, password);
ps=con.prepareStatement(dropTableQuery);

if(con!=null && ps!=null)
{

int result=ps.executeUpdate();

if(result==0)
{
System.out.println("Table Dropped Successfully");
}
else
{
System.out.println("Problem with Table Drop");
}

}
else
{
System.out.println("Problem with database or PreparedStatement");
}

}

catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}

}