class Method
{

    int a=90;//instance variable

    static void f1()//static method
    {
        System.out.println("Welcome to f1() method");
       
    }

    float add(float a,float b)//instane method
    {
        return a+b;
    }

    void wish(String name)//instance method
    {
        Method.f1();
        float result=add(10,20);
        System.out.println("Result is :"+result);
        System.out.println("Hello "+name +" Good Morning");
    }
   
    public static void main(String[] args)
    {

       Method m1=new Method();
       m1.wish("khizar");

    }
}