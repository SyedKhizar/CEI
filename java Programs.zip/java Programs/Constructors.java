class Constructors
{
int eid;
String ename;
String email;
String city;

Constructors(int eid,String ename,String email,String city)
{
this.eid=eid;
this.ename=ename;
this.email=email;
this.city=city;
}
   
 public static void main(String[] args) {
       
Constructors d1=new Constructors(1,"khizar","khizar@gmail.com","Bangalore");
Constructors d2=new Constructors(2,"akram","akram@gmail.com","Chennai");

System.out.println("Printing Instance Variable using Object d1");
System.out.println("Employee Id :"+d1.eid);
System.out.println("Employee Name :"+d1.ename);
System.out.println("Employee Email :"+d1.email);
System.out.println("Employee City :"+d1.city);

System.out.println("**********************************");

System.out.println("Printing Instance Variable using Object d2");
System.out.println("Employee Id :"+d2.eid);
System.out.println("Employee Name :"+d2.ename);
System.out.println("Employee Email :"+d2.email);
System.out.println("Employee City :"+d2.city);

 }
}