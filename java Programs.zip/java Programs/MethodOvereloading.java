class MethodOvereloading
{
    void add(int a,int b)
    {
        int c=a+b;
        System.out.println("Sum of 2 numbers :"+c);
    }

    void add(double a,double b)
    {
        double c=a+b;
        System.out.println("Sum of 2 realnumbers :"+c);
    }

    void add(int a,int b,int c)
    {
        int d=a+b+c;
        System.out.println("Sum of 3 numbers :"+d);
    }

    void wish(Object obj)
    {
        System.out.println("Welcome to Wish() method taking object as argument");
    }

    // void wish(String obj)
    // {
    //     System.out.println("Welcome to Wish() method taking String as argument");
    // }

    // void wish(MethodOvereloadingDemo obj)
    // {
    //     System.out.println("Welcome to wish() method taking MethodOverloadingDemo as argument");
    // }
    public static void main(String[] args)
    {

        MethodOvereloading d1=new MethodOvereloading();
        d1.add(10,90);

        d1.add(30.3,59.7);

        d1.add(1,2,3);

        d1.wish(null);
       
    }
}