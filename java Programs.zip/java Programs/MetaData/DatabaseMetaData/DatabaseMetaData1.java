package com.khizar;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;

public class DatabaseMetaData1  {
public static void main(String[] args) {

String username="root";
String password="root";
String url="jdbc:mysql://localhost:3306/jdbc";

Connection con=null;
DatabaseMetaData dbmd=null;

try {

con=DriverManager.getConnection(url, username, password);
if(con!=null)
{
System.out.println("Connection Established");
dbmd=con.getMetaData();

System.out.println("Database Name Is :"+dbmd.getDatabaseProductName());
System.out.println("Database Version Is :"+dbmd.getDatabaseProductVersion());
System.out.println("Database Major Version Is :"+dbmd.getDatabaseMajorVersion());
System.out.println("Database Minor Version Is :"+dbmd.getDatabaseMinorVersion());
System.out.println("Database Driver Class :"+dbmd.getDriverName());
System.out.println("Database URL  :"+dbmd.getURL());

}
else
{
System.out.println("Connection Not Established");
}

} catch (Exception e) {
System.out.println(e);
}
}
}