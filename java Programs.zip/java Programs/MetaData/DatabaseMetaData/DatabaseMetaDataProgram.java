package com.khizar;




import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.Statement;


public class DatabaseMetaDataProgram  {

public static void main(String[] args) {

Connection con=null;

Statement st=null;

String url="jdbc:mysql://localhost:3306/shop";
String username= "root";
String password= "root";


try {

con=DriverManager.getConnection(url,username,password);

DatabaseMetaData dbmd=con.getMetaData();

System.out.println("Database Name is :"+dbmd.getDatabaseProductName());

System.out.println("Database Major Version is :"+dbmd.getDatabaseMajorVersion());

System.out.println("Database Minor Version is :"+dbmd.getDatabaseMinorVersion());

System.out.println("Database Driver Name is :"+dbmd.getDriverName());

} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}



}