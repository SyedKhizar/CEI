package com.khizar;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class ParameterMetaData1
{

   public static void main(String[] args) {


String username="root";
String password="root";
String url="jdbc:mysql://localhost:3306/jdbc";

Connection con=null;
ResultSetMetaData rsmd=null;
PreparedStatement ps=null;
String selectQuery="select * from googlepay where acno=? and acname=?";
ParameterMetaData pmd=null;

ResultSet rs=null;
try {

con=DriverManager.getConnection(url, username, password);
if(con!=null)
{
System.out.println("Connection Established");
ps=con.prepareStatement(selectQuery);

ps.setInt(1,222);
ps.setString(2,"ghi");

ps.executeQuery();
pmd=ps.getParameterMetaData();

System.out.println(pmd.getParameterCount());





}
else
{
System.out.println("Connection Not Established");
}

} catch (Exception e) {

e.printStackTrace();
}
}
}