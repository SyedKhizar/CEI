package com.khizar;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ParameterMetaData;
import java.sql.ResultSet;
import java.sql.Types;

public class ParameterMetaData2
{

   public static void main(String[] args) {


String username="root";
String password="root";
String url="jdbc:mysql://localhost:3306/jdbc";

Connection con=null;
CallableStatement cs=null;
String selectProcedureQuery="{ call p11(?,?) }";
ParameterMetaData pmd=null;

//ResultSet rs=null;
try {

con=DriverManager.getConnection(url, username, password);
if(con!=null)
{
System.out.println("Connection Established");
cs=con.prepareCall(selectProcedureQuery);
cs.setInt(1,2);
cs.registerOutParameter(2,Types.VARCHAR);

cs.executeQuery();
pmd=cs.getParameterMetaData();

System.out.println(pmd.getParameterCount());
System.out.println(pmd.getParameterMode(2));
System.out.println(pmd.getParameterTypeName(1));
System.out.println(pmd.getParameterTypeName(2));



}
else
{
System.out.println("Connection Not Established");
}

} catch (Exception e) {

e.printStackTrace();
}
}
}