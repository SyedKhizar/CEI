package com.khizar;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class ResultSetMetaData1 {
public static void main(String[] args) {

String username="root";
String password="root";
String url="jdbc:mysql://localhost:3306/jdbc";

Connection con=null;
ResultSetMetaData rsmd=null;
PreparedStatement ps=null;
String selectQuery="select * from googlepay";

ResultSet rs=null;
try {

con=DriverManager.getConnection(url, username, password);
if(con!=null)
{
System.out.println("Connection Established");
ps=con.prepareStatement(selectQuery);

rs=ps.executeQuery();

rsmd=rs.getMetaData();

System.out.println("Table Name :"+rsmd.getTableName(1));
System.out.println("Name of Column1:"+rsmd.getColumnName(1));
System.out.println("Name of Column2:"+rsmd.getColumnName(2));
System.out.println("Data Type of Column-1 "+rsmd.getColumnTypeName(1));
System.out.println("Data Type of Column-2 "+rsmd.getColumnTypeName(2));



}
else
{
System.out.println("Connection Not Established");
}

} catch (Exception e) {
System.out.println(e);
}
}
}