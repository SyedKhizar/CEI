package com.khizar;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class ResultSetMetaDataProgram  {

public static void main(String[] args) {
// TODO Auto-generated method stub


Connection con=null;

Statement st=null;

ResultSet rs=null;
String url="jdbc:mysql://localhost:3306/shop";
String username= "root";
String password= "root";

try {

con=DriverManager.getConnection(url,username,password);

st=con.createStatement();

rs=st.executeQuery("select * from employees");

ResultSetMetaData rsmd=rs.getMetaData();

System.out.println(rsmd.getColumnName(1));
System.out.println(rsmd.getColumnName(2));
System.out.println(rsmd.getColumnName(3));
System.out.println(rsmd.getColumnName(4));

System.out.println(rsmd.getColumnTypeName(1));
System.out.println(rsmd.getColumnTypeName(2));

System.out.println(rsmd.getColumnCount());

} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}

}

}