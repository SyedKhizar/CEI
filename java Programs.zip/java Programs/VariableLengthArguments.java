public class VariableLengthArguments {


    int add(int ... result)
    {
        int sum=0;
        for (int i = 0; i < result.length; i++) {
           
            sum=sum+result[i];
        }
        return sum;
   }

   //multiplication
   //substraction
   //division
   //average


    public static void main(String[] args) {

       VariableLengthArguments d1=new VariableLengthArguments();

       int result1=d1.add(10);//10
       int result2=d1.add(10,20);//30
       int result3=d1.add(10,20,30,40);//100
       int result4=d1.add(10,20,30);//60

       System.out.println("Sum is :"+result1);
       System.out.println("Sum is :"+result2);
       System.out.println("Sum is :"+result3);
       System.out.println("Sum is :"+result4);
       

       
    }
   
}