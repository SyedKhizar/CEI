package com.khizar;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class JdbcCallableStatementSelect {

public static void main(String[] args) {
// TODO Auto-generated method stub

String username="root";
String password="root";
String url="jdbc:mysql://localhost:3306/jdbc";

Connection con=null;
CallableStatement cs=null;
String selectProcedure="{call p1()}";
ResultSet rs=null;

try {

con=DriverManager.getConnection(url, username, password);

if(con!=null)
{
System.out.println("Connection Established");
cs=con.prepareCall(selectProcedure);

rs=cs.executeQuery();
while(rs.next())
{
int acno=rs.getInt(1);
String acname=rs.getString(2);
float balance=rs.getFloat(3);
String city=rs.getString(4);

System.out.println("Accno :"+acno);
System.out.println("Accname :"+acname);
System.out.println("Account Balance :"+balance);
System.out.println("City :"+city);

System.out.println("--------------------------------");
}
}
else
{
System.out.println("Connection Not Established");
}


} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}

}

}