package com.khizar;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Scanner;

public class JdbcCallableStatementDelete {

public static void main(String[] args) {
// TODO Auto-generated method stub

String username="root";
String password="root";
String url="jdbc:mysql://localhost:3306/jdbc";

Connection con=null;
CallableStatement cs=null;
String updateProcedure="{call p4(?)}";

Scanner sc=new Scanner(System.in);

System.out.print("Enter Acno to delete :");
int acno=sc.nextInt();

try {

con=DriverManager.getConnection(url, username, password);

if(con!=null)
{
cs=con.prepareCall(updateProcedure);
cs.setInt(1,acno);

int result=cs.executeUpdate();
if(result==1)
{
System.out.println(result+" Record Deleted");
}
else
{
System.out.println("Failed to Delete Record");
}
}
else
{
System.out.println("Connection Not Established");
}


} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}

}

}