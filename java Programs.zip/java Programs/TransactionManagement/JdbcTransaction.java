package com.khizar;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JdbcTransaction {

public static void main(String[] args) {

Connection con=null;
PreparedStatement ps=null;

PreparedStatement ps1=null;

String url="jdbc:mysql://localhost:3306/shop";
String username= "root";
String password= "root";
String insertQuery="insert into employees values (?,?,?,?)";
String deleteQuery="delete from employees where eid=?";

try
{


con=DriverManager.getConnection(url, username, password);

con.setAutoCommit(false);

ps=con.prepareStatement(insertQuery);

ps1=con.prepareStatement(deleteQuery);

ps.setInt(1,8);
ps.setString(2,"ntr");
ps.setString(3,"Kerela");
ps.setString(4,"ntr@gmail.com");

ps1.setInt(1,2);

int result1=ps1.executeUpdate();

int result=ps.executeUpdate();

if(result==1 && result1==1)
{
System.out.println("Transaction Success");
System.out.println("Employee With ID  6 Inserted Successfully ");
System.out.println("Employee With ID  2 Deleted Successfully");
con.commit();
}
else
{
System.out.println("Transaction Failed");
   System.out.println("Problem with Record Insertion or Deletion");
    con.rollback();
}

}

catch (Exception e) {

System.out.println(e);

try {
con.rollback();
} catch (SQLException e1) {

System.out.println(e1);
}

}

}

}