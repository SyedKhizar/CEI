package com.khizar;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
public class JdbcTransactionManagement {
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);

String username="root";
String password="root";
String url="jdbc:mysql://localhost:3306/jdbc";

Connection con=null;
Statement st1=null;
Statement st2=null;
Statement st3=null;
Statement st4=null;

System.out.print("Enter PAYTM Acno :");
int acno=sc.nextInt();

System.out.print("Enter Amount to Transfer :");
float amount=sc.nextFloat();

System.out.print("Enter Destination Accno :");
int destinationacno=sc.nextInt();

String sourceAccountBalanceQuery="select balance from paytm_Accounts where acno='"+acno+"'";
String destinationAccountBalanceQuery="select balance from paytm_Accounts where acno='"+destinationacno+"'";



String updateSourceQuery="";
String updateDestinationQuery="";


try {

con=DriverManager.getConnection(url, username, password);

if(con!=null)
{
System.out.println("Connection Established");
con.setAutoCommit(false);
st1=con.createStatement();
st2=con.createStatement();
st3=con.createStatement();
st4=con.createStatement();

ResultSet rs1=st1.executeQuery(sourceAccountBalanceQuery);
ResultSet rs2=st2.executeQuery(destinationAccountBalanceQuery);

rs1.next();
rs2.next();

float sourceAccountBalance=rs1.getFloat(1);
float destinationAccountBalance=rs2.getFloat(1);

if(sourceAccountBalance<amount)
{
System.out.println("Insufficient Funds ........");
}
else
{
updateSourceQuery="update paytm_Accounts set balance='"+(sourceAccountBalance-amount)+"' where acno='"+acno+"'";
updateDestinationQuery="update paytm_Accounts set balance='"+(destinationAccountBalance+amount)+"' where acno='"+destinationacno+"'";


int result1=st3.executeUpdate(updateSourceQuery);
int result2=st4.executeUpdate(updateDestinationQuery);

if(result1==1 && result2==1)
{
con.commit();
System.out.println("Transaction Successful");
System.out.println(amount + " Transferred To Destination Account :"+destinationacno);
}
else
{
con.rollback();
System.out.println("Transaction Failed .....");
}
}



}
else
{
System.out.println("Connection Not Established");
}

} catch (Exception e) {

System.out.println(e);
}


}

}