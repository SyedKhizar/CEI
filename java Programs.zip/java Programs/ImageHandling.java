import java.io.*;
public class ImageHandling {

    public static void main(String[] args) {
       
        File f1=null;
        File f2=null;
        FileInputStream fis=null;
        FileOutputStream fos=null;
        byte b[];


        try {
            f1=new File("lion1.jpg");

            b=new byte[(int)f1.length()];//creating an array whose size is equal to file size

            f2=new File("lion2.jpg");

            fis=new FileInputStream(f1);

            fis.read(b);//reads binary data into byte array b

            fos=new FileOutputStream(f2);

            fos.write(b);//writes binary data from byte array b to destination file

            System.out.println("New Image Created Successfully");


               

        } catch (Exception e) {
            //TODO: handle exception
            System.out.println(e);
        }
    }
   
}