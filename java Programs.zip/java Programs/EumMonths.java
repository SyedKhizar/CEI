enum Months
{
    JANUARY,FEBRUARY,MARCH,APRIL,MAY,JUNE,JULY,AUGUST,SEPTEMBER,OCTOBER,NOVEMBER,DECEMBER;

    Months()
    {
        System.out.println("enum Months Constructor");
    }


    public static void main(String[] args) {
        System.out.println("Welcome to enum main method");
    }


}