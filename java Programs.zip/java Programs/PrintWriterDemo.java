import java.io.*;
public class PrintWriterDemo {

    public static void main(String[] args) {

        PrintWriter pw=null;
    try {
        pw=new PrintWriter("students.txt");

        pw.println(100);
        pw.println(552525);
        pw.println(4144141);
        pw.println(9346450004l);
        pw.println("khizar");
        pw.println('S');
        pw.println(1414.14141f);
        pw.println(2215215.5151);

        pw.flush();

        System.out.println("Data Written to File Successfully");
       
       
    } catch (Exception e) {
        //TODO: handle exception
        System.out.println(e);
    }
       
    }
   
}