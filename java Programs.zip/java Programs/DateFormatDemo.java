import java.text.*;
import java.util.Date;
import java.util.Locale;
public class DateFormatDemo
{
public static void main(String[] args)
{

    Date d1=new Date();

    DateFormat dfg1=DateFormat.getDateInstance(3,Locale.GERMANY);
    DateFormat dfg2=DateFormat.getDateInstance(DateFormat.MEDIUM,Locale.GERMANY);
    DateFormat dfg3=DateFormat.getDateInstance(DateFormat.LONG,Locale.GERMANY);
    DateFormat dfg4=DateFormat.getDateInstance(0,Locale.GERMANY);


    Locale l1=new Locale("hi","IN");
    DateFormat dfi1=DateFormat.getDateInstance(3,l1);
    DateFormat dfi2=DateFormat.getDateInstance(DateFormat.MEDIUM,l1);
    DateFormat dfi3=DateFormat.getDateInstance(DateFormat.LONG,l1);
    DateFormat dfi4=DateFormat.getDateInstance(0,l1);


    System.out.println("Date Representation in Germany Short Form:"+dfg1.format(d1));
    System.out.println("Date Representation in Germany Medium Form:"+dfg2.format(d1));
    System.out.println("Date Representation in Germany Long Form:"+dfg3.format(d1));
    System.out.println("Date Representation in Germany Full Form:"+dfg4.format(d1));

    System.out.println("******************************************************************");

    System.out.println("Date Representation in India Short Form:"+dfi1.format(d1));
    System.out.println("Date Representation in India Medium Form:"+dfi2.format(d1));
    System.out.println("Date Representation in India Long Form:"+dfi3.format(d1));
    System.out.println("Date Representation in India Full Form:"+dfi4.format(d1));


   
}    
}