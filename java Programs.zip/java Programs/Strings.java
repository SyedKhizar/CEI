class Strings
{
    public static void main(String[] args)
    {
        char ch[]={'H','Y','D','E','R','A','B','A','D'};

        byte b[]={97,98,99,100};//abcd
       
        String s1=new String();
        String s2=new String("bangalore");
        String s3="KARNATAKA";

        String s4=new String(ch);
        String s5=new String(b);

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(s4);
        System.out.println(s5);

        System.out.println("Length of String :"+s2+" is :"+s2.length());
        System.out.println("Length of String :"+s5+" is :"+s5.length());

        System.out.println("State is :"+s3.concat("State"));

        System.out.println("String s2 :"+s2);
        System.out.println("String s2 :"+s2.toUpperCase());

        System.out.println("String s3 :"+s3);
        System.out.println("String s3 :"+s3.toLowerCase());


        System.out.println("Character Located at index position 2 for String :"+s4+"is "+s4.charAt(2));

        System.out.println("substring in string "+s3+" is :"+s3.substring(1));

        System.out.println("substring in string "+s3+" is :"+s3.substring(1,9));

        System.out.println(s4.replace('H','C'));

        String dob="17-09-1990";

        String website="www.redbus.in";

        String s[]=dob.split("-");

        for(int i=0;i<s.length;i++)
        {
            System.out.println(s[i]);
        }

        String w[]=website.split("\\.");

        for(int i=0;i<w.length;i++)
        {
            System.out.println(w[i]);
        }



    }
}