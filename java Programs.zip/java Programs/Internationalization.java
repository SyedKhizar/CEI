
import java.util.*;
public class Internationalization
{

    public static void main(String[] args) {
       
        Locale l1=new Locale("tk","IN");
        // Locale l02=new Locale("pa","IN");

        // Locale l3=new Locale("AP","IN");

        System.out.println(l1.getLanguage());
        System.out.println(l1.getDisplayLanguage());

        // System.out.println(l2.getLanguage());
        // System.out.println(l2.getDisplayLanguage());

        // System.out.println(l3.getLanguage());
        // System.out.println(l3.getDisplayLanguage());


       String iso2[]=l1.getISOLanguages();

       for(String iso1:iso2)
        {
            System.out.println(iso1);
        }

       String s2[]= l1.getISOCountries();

       System.out.println("*******************************");
        for(String s1:s2)
        {
            System.out.println(s1);
        }



    }
   
}