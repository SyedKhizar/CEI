
import java.io.*;
public class BufferedWriters {

    public static void main(String[] args) {

        File f1=null;
        FileWriter fw=null;
        BufferedWriter bw=null;

        try {

            f1=new File("xyz.txt");
            fw=new FileWriter(f1,true);
            bw=new BufferedWriter(fw);

            bw.write("khizar");
            bw.newLine();
            bw.write("akram");

            bw.newLine();
           

            char ch[]={'A','B','C','D','E'};

            bw.write(ch);

            bw.flush();


           
        } catch (Exception e) {
            //TODO: handle exception
            System.out.println(e);
        }
       
    }
   
}