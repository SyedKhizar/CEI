/*
public class Employee implements java.io.Serializable
{
    int eid;
    String ename;
    transient String email;

    Employee(int eid,String ename,String email)
    {
        this.eid=eid;
        this.ename=ename;
        this.email=email;
    }
   
}
*/


import java.io.*;
public class Deserialization
{

    public static void main(String[] args)throws Exception
    {

        File f=new File("employee.txt");
        FileInputStream fis=new FileInputStream(f);

        ObjectInputStream ois=new ObjectInputStream(fis);

        Employee e1=(Employee)ois.readObject();
        System.out.println("Employee ID :"+e1.eid);
        System.out.println("Employee Name :"+e1.ename);
        System.out.println("Employee Email:"+e1.email);
       
    }
   
}