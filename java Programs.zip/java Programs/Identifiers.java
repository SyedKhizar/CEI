public class Identifiers {
    public static void main(String[] args) {
        int a =90;
        int aA=900;
        int a123=9000;
        int employees$=123;
        int emp_salary=456;
       int xyz@123=175; // Invalid @
    }
    
}
