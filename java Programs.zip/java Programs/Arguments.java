
public class Arguments
{
void f1(int a, int b) {

}

void f1 (int a, int b,int c)
{c=a+b;
    return c;
}
public static void main(String[] args) {
Arguments a1 = new Arguments();
a1.f1(10,20,30);


}
}