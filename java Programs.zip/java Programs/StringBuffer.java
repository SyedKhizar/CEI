
public class StringBufferDemo {
    public static void main(String[] args) {
        StringBuffer sb1=new StringBuffer();
        System.out.println(sb1.capacity());

        sb1.append("Bangalore");
        System.out.println(sb1.capacity());
        sb1.append("Bangalore");
        System.out.println(sb1.capacity());

        System.out.println(sb1.length());

        StringBuffer sb2=new StringBuffer(50);

        System.out.println(sb2.capacity());

        StringBuffer sb3=new StringBuffer("welcome");

        System.out.println(sb3);

        // sb3.reverse();

        // System.out.println(sb3);

        sb3.deleteCharAt(1);

        System.out.println(sb3);

        StringBuffer sb4=new StringBuffer("ABCDEFG");

        sb4.delete(1,6);

        System.out.println(sb4);

    }
   
}