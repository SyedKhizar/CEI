public class Static
{
   static
    {
        System.out.println("Static Block-1 Executed");
    }
    static
    {
        System.out.println("Static Block-2 Executed");
    }

    public static void main(String[] args)
    {
             
    }
   
}