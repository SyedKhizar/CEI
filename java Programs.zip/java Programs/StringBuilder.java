public class StringBuilderDemo {
    public static void main(String[] args) {
        StringBuilder sb1=new StringBuilder();
        System.out.println(sb1.capacity());

        sb1.append("Bangalore");
        System.out.println(sb1.capacity());
        sb1.append("Bangalore");
        System.out.println(sb1.capacity());

        System.out.println(sb1.length());

        StringBuilder sb2=new StringBuilder(50);

        System.out.println(sb2.capacity());

        StringBuilder sb3=new StringBuilder("welcome");

        System.out.println(sb3);

        // sb3.reverse();

        // System.out.println(sb3);

        sb3.deleteCharAt(1);

        System.out.println(sb3);

        StringBuilder sb4=new StringBuilder("ABCDEFG");

        sb4.delete(1,6);

        System.out.println(sb4);

    }
   

}