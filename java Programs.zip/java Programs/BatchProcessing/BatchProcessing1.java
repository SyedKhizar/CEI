package com.khizar;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class BatchProcessing1 {

public static void main(String[] args) {

Connection con=null;
Statement st=null;


String username="root";
String password="root";
String url="jdbc:mysql://localhost:3306/jdbc";

String insertQuery="insert into googlepay values(666,'kim',7896.45,'goa')";
String deleteQuery="delete from googlepay where acno=222";
String updateQuery="update googlepay set acname='tim' where acno=3698";

try {


con=DriverManager.getConnection(url, username, password);

st=con.createStatement();

st.addBatch(insertQuery);
st.addBatch(deleteQuery);
st.addBatch(updateQuery);

st.executeBatch();

System.out.println("Batch Processing Completed");


} catch (Exception e) {

System.out.println(e);
}

}

}