package com.khizar;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class BatchProcessing
{

public static void main(String[] args) {
// TODO Auto-generated method stub

Connection con=null;
PreparedStatement ps=null;

Statement st=null;

String url="jdbc:mysql://localhost:3306/shop";
String username= "root";
String password= "root";
String insertQuery="insert into employees values (6,'Bala Krishna','Hyd','bala@yahoo.in')";
String deleteQuery="delete from employees where eid =8";
String updateQuery=" update employees set ecity='pune' where eid=4 ";

try
{


con=DriverManager.getConnection(url, username, password);

//con.setAutoCommit(false);


st=con.createStatement();

st.addBatch(insertQuery);
st.addBatch(deleteQuery);
st.addBatch(updateQuery);

int results[]=st.executeBatch();


for(int result:results)
{
System.out.println(result);
}

}

catch (Exception e) {
// TODO: handle exception
System.out.println(e);



}


}

}