public class CommandLineArguments {
   
    public static void main(String[] args) {

        int sum=1;
        for(int i=0;i<args.length;i++)
        {
              int j=Integer.parseInt(args[i]);
            sum=sum*j;
        }
        System.out.println("Product is :"+sum);

       
    }
}