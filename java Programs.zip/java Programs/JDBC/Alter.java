package com.khizar;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Alter {

public static void main(String[] args) {

Connection con=null;
String url="jdbc:mysql://localhost:3306/company";
String user="root";
String password="root";
Statement st=null;

String alterQuery="alter table employees add column(quality varchar(50))";

try {


con=DriverManager.getConnection(url, user, password);
st=con.createStatement();
int result=st.executeUpdate(alterQuery);


if(result==0)
System.out.println("Table altered succesfully ");
else
System.out.println("table not altered");

} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}
}