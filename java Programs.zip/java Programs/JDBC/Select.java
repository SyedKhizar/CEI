package com.khizar;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;


public class Select  {

public static void main(String[] args) {

Connection con=null;
String url="jdbc:mysql://localhost:3306/company";
String user="root";
String password="root";
Statement st=null;
ResultSet rs = null;

String selectQuery="select * from employees";

try {


con=DriverManager.getConnection(url, user, password);
st=con.createStatement();
rs=st.executeQuery(selectQuery);
while(rs.next())
{
int eid = rs.getInt(1);
String ename = rs.getString(2);
String ecity = rs.getString(3);
String email = rs.getString(4);
System.out.println("Displaying Employee details with ID : "+eid);
System.out.println("**********************************");
System.out.println("Employee Name: "+ename);
System.out.println("Employee City: "+ecity);
System.out.println("Employee Email: "+email);
System.out.println("---------------------");

}


} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}
}