package com.khizar;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class Update{

public static void main(String[] args) {

Connection con=null;
String url="jdbc:mysql://localhost:3306/company";
String user="root";
String password="root";
Statement st=null;
Scanner sc=new Scanner(System.in);

System.out.print("Enter Employee ID :");
int eid=sc.nextInt();
System.out.print("Enter Employee email to update");
String email=sc.next();

String updateQuery="update employees set email = '"+email+"' where eid = '"+eid+"' ";

try {


con=DriverManager.getConnection(url, user, password);
st=con.createStatement();
int result=st.executeUpdate(updateQuery);


if(result==1)
System.out.println("Employee with ID: "+eid+" Email is updated :"+email);
else
System.out.println("Failed to update Email ID for Employee with ID" +eid);

} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}
}