package com.khizar;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class Insert {

public static void main(String[] args) {
// TODO Auto-generated method stub
Connection con=null;
String url="jdbc:mysql://localhost:3306/company";
String user="root";
String password="root";
Statement st=null;
Scanner sc=new Scanner(System.in);

System.out.print("Enter Employee ID :");
int eid=sc.nextInt();

System.out.print("Enter Employee Name :");
String ename=sc.next();

System.out.print("Enter Employee City :");
String ecity=sc.next();

System.out.print("Enter Employee Email :");
String email=sc.next();

String insertQuery="insert into employees values('"+eid+"','"+ename+"','"+ecity+"','"+email+"')";

try {

//Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection(url, user, password);

if(con!=null)
{
System.out.println("Connection Established");
st=con.createStatement();

int result=st.executeUpdate(insertQuery);
if(result==1)
System.out.println(result+" Record inserted Successfully");
else
System.out.println("Problem With Record Insertion");
}

 else
System.out.println("Connection Not Established");

} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}
