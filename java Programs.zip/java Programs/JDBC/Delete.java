package com.khizar;

 


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class Delete {

public static void main(String[] args) {
// TODO Auto-generated method stub
Connection con=null;
String url="jdbc:mysql://localhost:3306/company";
String user="root";
String password="root";
Statement st=null;
Scanner sc=new Scanner(System.in);

System.out.print("Enter Employee ID to Delete:");
int eid=sc.nextInt();



String deleteQuery="delete from employees where eid='"+eid+"' ";

try {

//Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection(url, user, password);

if(con!=null)
{
System.out.println("Connection Established");
st=con.createStatement();

int result=st.executeUpdate(deleteQuery);
if(result==1)
System.out.println(result+" Record Deleted Successfully");
else
System.out.println("Problem With Record Deletion");
}

 else
System.out.println("Connection Not Established");

} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}

}