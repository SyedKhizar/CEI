package com.khizar;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class Drop  {

public static void main(String[] args) {

Connection con=null;
String url="jdbc:mysql://localhost:3306/company";
String user="root";
String password="root";
Statement st=null;

String dropQuery="drop table emp";

try {


con=DriverManager.getConnection(url, user, password);
st=con.createStatement();
int result=st.executeUpdate(dropQuery);


if(result==0)
System.out.println("Table dropped succesfully ");
else
System.out.println("table not dropped");

} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}
}