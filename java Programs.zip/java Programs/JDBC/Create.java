package com.khizar;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class Create  {

public static void main(String[] args) {
Connection con=null;
String url="jdbc:mysql://localhost:3306/company";
String user="root";
String password="root";
Statement st=null;
String createTableQuery="create table employed(eid int primary key,ename varchar(100),ecity varchar(100),email varchar(100))";
try {

//Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection(url, user, password);

if(con!=null)
{
System.out.println("Connection Established");
st=con.createStatement();

int result=st.executeUpdate(createTableQuery);
if(result==0)
System.out.println("Table Created Successfully");
else
System.out.println("Problem With Table Creation");
}

 else
System.out.println("Connection Not Established");

} catch (Exception e) {
// TODO: handle exception
System.out.println(e);
}


}

}
