import java.io.*;
public class FileWriterDemo {

    public static void main(String[] args) {

        File f1=null;
        FileWriter fw=null;

        try {

            f1=new File("xyz.txt");
            fw=new FileWriter(f1,true);

            fw.write("khizar");
            fw.write("\n");
            fw.write("akram");
            fw.write("\n");

            char ch[]={'A','B','C','D','E'};

            fw.write(ch);

            fw.flush();


           
        } catch (Exception e) {
            //TODO: handle exception
            System.out.println(e);
        }
       
    }
   
}