class Variables
{
       public static void main(String[] args)
    {

       System.out.println("Maximum Value for int :"+Integer.MAX_VALUE);
       System.out.println("Minimum Value for int :"+Integer.MIN_VALUE);

       System.out.println("Maximum Value for long :"+Long.MAX_VALUE);
       System.out.println("Minimum Value for long :"+Long.MIN_VALUE);
    }
}