class ImplicitTypeCasting
{
    public static void main(String[] args) {
       
        byte b1=100;
        int i1=b1;

        int i2=1000;
        long b2=i2;

       


         

    }
}