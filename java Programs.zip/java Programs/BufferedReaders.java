import java.io.*;
public class BufferedReaders {


    public static void main(String[] args) {

     
        FileReader fr=null;
        BufferedReader br=null;


        try {

           
            fr=new FileReader("abc.txt");
            br=new BufferedReader(fr);

            String s1=br.readLine();

            while(s1!=null)
            {
                System.out.println(s1);
                s1=br.readLine();
            }

           
        } catch (Exception e) {
            //TODO: handle exception
            System.out.println(e);
        }
       
    }
   
}