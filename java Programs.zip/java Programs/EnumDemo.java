class EnumDemo
{
    public static void main(String[] args) {
       

    Months jan=Months.JANUARY;
    Months oct=Months.OCTOBER;

    Months[] m=Months.values();

   
    System.out.println(jan.ordinal());
    System.out.println(oct.ordinal());
       
    System.out.println("Displaying Constants Of enum Months");

    for(int i=0;i<m.length;i++)
    {
        System.out.println(m[i]);
    }


    }
}