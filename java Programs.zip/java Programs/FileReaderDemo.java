import java.io.*;
public class FileReaderDemo {

    public static void main(String[] args) {
        File f1=null;
        FileReader fr=null;
        try {

            f1=new File("abc.txt");
            fr=new FileReader(f1);

            int i=fr.read();

            while(i!=-1)
            {
                System.out.print((char)i);
                i=fr.read();

            }



           
        } catch (Exception e) {
            //TODO: handle exception
            System.out.println(e);
        }
    }
   
}