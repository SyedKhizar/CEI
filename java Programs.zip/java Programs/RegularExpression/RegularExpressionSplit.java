
import java.util.regex.Pattern;

public class RegularExpressionSplit {
    public static void main(String[] args) {
       
        String target="www.youtube.com";

        Pattern p=Pattern.compile("\\.");

        String s[]=p.split(target);
       
        for(String s1:s)
        {
            System.out.println(s1);
        }

        String mobile="7842784212 7889788978 9346450004 7474787878";

        Pattern p1=Pattern.compile("\\s");

        String mobiles[]=p1.split(mobile);

        for(String mobile1:mobiles)
        {
            System.out.println(mobile1);
        }

        System.out.println("Splitting Target String accroding to regular expression using split() method of String class");

        String website="www.angular.io";

        String w[]=website.split("\\.");

        for(String w1:w)
        {
            System.out.println(w1);
        }


    }
   
}