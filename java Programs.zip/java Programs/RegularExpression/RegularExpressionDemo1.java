import java.util.regex.*;
public class RegularExpressionDemo1 {

    public static void main(String[] args) {

        String target=" abhay bravia";

        Pattern p=Pattern.compile("[^ab\\s]");//except a or b or space

        Matcher matcher=p.matcher(target);

        while(matcher.find())
        {
            System.out.println("First Position:"+matcher.start()+" End Position :"+matcher.end()+" Matched String :"+matcher.group());
        }


    }
}