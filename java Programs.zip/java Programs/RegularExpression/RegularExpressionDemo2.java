import java.util.regex.*;
public class RegularExpressionDemo2 {
    public static void main(String[] args) {

        String target="abhay aa braviaa aaa praveen aamericaaaaa";

        Pattern p=Pattern.compile("[a]*");

        Matcher matcher=p.matcher(target);

        while(matcher.find())
        {
            System.out.println("Start Position:"+matcher.start()+" End Position :"+matcher.end()+" Matched String :"+matcher.group());
        }
       
    }
   
}