import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class MobileNumberValidation {
    public static void main(String[] args) {
       
        Scanner sc=new Scanner(System.in);

        System.out.print("Enter Mobile Number:");
        String mobile=sc.next();

        Pattern p=Pattern.compile("(0|91)?[6-9][\\d]{9}");

        Matcher m1=p.matcher(mobile);

        if(m1.find() && m1.group().equals(mobile))
        {
            System.out.println("Mobile Number is Valid");
        }
        else
        {
            System.out.println("Invalid Mobile Number");
        }
    }
}