import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class EmailValidation {
  public static void main(String[] args) {
     
   

    Scanner sc=new Scanner(System.in);
   
    System.out.print("Enter Your Email: ");
    String email=sc.next();

    String e="[a-zA-z0-9._]*@gmail.com";
    String e1="@gmail.com";
    String e2=email+e1;
    Pattern p1=Pattern.compile(e);

    Matcher m=p1.matcher(e2);

   

    if(m.find() && m.group().equals(e2))
    {
       System.out.println("Mail Id is Valid");
       System.out.println("Entered Email :"+e2);
    }
    else
       System.out.println("Mail Id is Not Valid");
   


  }  
}