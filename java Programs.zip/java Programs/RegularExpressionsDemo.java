import java.util.regex.*;
public class RegularExpressionsDemo {
   
    public static void main(String[] args) {
       
        String target="Welcome to Java Regular Expressions in Java";

        Pattern pattern=Pattern.compile("Java");

        Matcher matcher=pattern.matcher(target);

        while(matcher.find())
        {
    System.out.println("Start Position :"+matcher.start()+" End Position :"+matcher.end()+" Matched String :"+matcher.group());
 
        }

    }
}