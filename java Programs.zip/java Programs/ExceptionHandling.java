



public class ExceptionHandling {

    public static void main(String[] args) {
        int a=10,b=0,c;

        System.out.println("Before Exception");
        try
        {
            c=a/b;
            System.out.println("Result is :"+c);
        }

        catch(Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            System.out.println("Finally Block Executed");
        }

        System.out.println("After Exception");
       
       
    }
   
}