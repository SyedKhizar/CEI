public class NumberFormatDemo {

        public static void main(String[] args) {
         
                double d=1234567.123;

                NumberFormat nf1=NumberFormat.getCurrencyInstance(Locale.US);
               
                Locale l1=new Locale("pa","IN");
               
                NumberFormat nf2=NumberFormat.getCurrencyInstance(l1);
                NumberFormat nf3=NumberFormat.getCurrencyInstance(Locale.ITALY);
                NumberFormat nf4=NumberFormat.getCurrencyInstance(Locale.GERMANY);
                NumberFormat nf5=NumberFormat.getInstance(Locale.FRANCE);


                System.out.println("US Form :"+nf1.format(d));
                System.out.println("Indian Form :"+nf2.format(d));
                System.out.println("Italy Form :"+nf3.format(d));
                System.out.println("Germany Form :"+nf4.format(d));
                System.out.println("France Form :"+nf5.format(d));


        }
}