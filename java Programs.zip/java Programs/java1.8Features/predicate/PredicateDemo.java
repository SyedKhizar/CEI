import java.util.function.Predicate;

public class PredicateDemo
{

    // public boolean test(Object t)
    // {
    //     Integer i=(Integer)t;
    //     boolean result=false;
    //     if(i%2==0)
    //     {
    //         result=true;
    //     }
    //     else
    //     {
    //         result=false;
    //     }
    //     return result;
               
    // }

    public static void main(String[] args) {
             
        Predicate<StringBuffer> p1=(StringBuffer name)->name.reverse().equals(name);
       
        StringBuffer name=new StringBuffer("sir");
        boolean result=p1.test(name);

        if(result)
              System.out.println(name+" is an Palindrome");
   
        else
              System.out.println(name+" is not Palindrome");
       
    }
   
}