
public interface I3
{
    //constants
    public static final int accno=225252;
    public static final double balance=225252.2525;

    //abstract methods
    public abstract void add(int a,int b);
    public abstract void mul(int a,int b);

    //From java 1.8v Default MEthods can be there inside interface

    public default void f1()
    {
      System.out.println("Welcome to f1() default method");  
    }

   
}