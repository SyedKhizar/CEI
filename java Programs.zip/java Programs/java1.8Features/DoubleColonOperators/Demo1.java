public class Demo1
{

    public int f2(int a,int b)
    {
        return a*b;
    }

    public static void main(String[] args)
    {

        Demo1 d1=new Demo1();
       
        I2 obj2=d1::f2;

        int result=obj2.mul(10,912);
        System.out.println("Result is :"+result);
       
    }
   
}