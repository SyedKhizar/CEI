public class Demo2 {
   
    Demo2(int n)
    {
        int c=n*n*n;
        System.out.println("Cube of a number :"+c);
    }
   
    public static void main(String[] args)
    {

        I3 obj1=Demo2::new;
        obj1.cube(10);
       
    }
   
}