public class Demo2
{

    public static void main(String[] args) {
       
        I2 obj=name->name.length();

        String s1="abcdef";
        int l=obj.findCharacters(s1);
        System.out.println("Number of Characters inside String :"+s1+" is :"+l);

    }
   
}