



import java.util.function.Function;

public class FunctionDemo
{

   public static void main(String[] args)
    {

        Function<Integer,Boolean> obj1=i->i%2==0;

        Boolean result=(Boolean)obj1.apply(13);
       
        if(result) System.out.println("IT is an Even Number");
        else System.out.println("It is an Odd Number");
    }
   
}