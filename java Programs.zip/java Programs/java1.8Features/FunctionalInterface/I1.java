@FunctionalInterface
public interface I1 //it is a functional interface
{
  public abstract  int add(int a,int b);
   
}


/**
 * InnerI2
 */