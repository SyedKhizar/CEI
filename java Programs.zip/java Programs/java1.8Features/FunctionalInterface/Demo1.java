public class Demo1
{
   
/*
public void add(int a, int b)
{
    int c=a+b;
    System.out.println("Addition is :"+c);        
}

*/

public static void main(String[] args)
{

    I1 obj=(a,b)->a+b;

    obj.add(10,10);
    obj.add(99,101);
   
}

   
}