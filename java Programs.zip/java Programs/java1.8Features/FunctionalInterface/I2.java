@FunctionalInterface
public interface I2
{
public abstract int findCharacters(String name);
}
