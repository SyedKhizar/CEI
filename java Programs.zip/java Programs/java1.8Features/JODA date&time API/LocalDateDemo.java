

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.Month;

public class LocalDateDemo
{
    public static void main(String[] args)
    {

        LocalDate ld1=LocalDate.now();
        int dayOfYear=ld1.getDayOfYear();
        int dayOfMonth=ld1.getDayOfMonth();
        Month month=ld1.getMonth();
       
               
        LocalTime lt1=LocalTime.now();

        int hours=lt1.getHour();
        int minutes=lt1.getMinute();
        int seconds=lt1.getSecond();


        LocalDateTime ldt1=LocalDateTime.now();

        System.out.println("Day of Year :"+dayOfYear);
        System.out.println("Day of Month  :"+dayOfMonth);
        System.out.println("Current Month :"+month.name());
        System.out.println("Current Date :"+ld1);

        System.out.println("***************************************************");
        System.out.println("Current Time :"+lt1);
        System.out.println("Hours :"+hours);
        System.out.println("Minutes :"+minutes);
        System.out.println("Seconds :"+seconds);

        System.out.printf("%d:%d:%d",hours,minutes,seconds);
        System.out.println();
        System.out.println("********************************************************");
        System.out.println("Current Date And Time :"+ldt1);
       
       
    }
   
}