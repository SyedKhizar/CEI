class Modifiers {

    //Protected Modifier
   protected int a=90;
    protected Modifiers()
    {

    }


   protected void f1()
    {

    }

    public static void main(String[] args) {
       
    }
   
}

//Private Modifier

/*
private int a=90;
private Modifiers()
{

}


private void f1()
{

}
 public static void main(String[] args) {
       
    }
*/

//Default Modifier

/*
int a=90;
Modifiers()
{

}

void f1()
{

}
 public static void main(String[] args) {
       
    }
*/

//Public Modifier

/*
 int a=90;
Modifiers()
{

}


public void f1()
{

}
 public static void main(String[] args) {

    modifiers d1 =new Modifiers();
    System.out.println(d1.a);
    d1.f1();
       
    }
*/

//Final Modifier

/*

final public class Parent{ // Cannot inherit from final parent
    void f1()
    {
        System.out.println("Hello");
            }
}
public class Child extends Parent{
public static void main(String[] args)
{
    Child c1 =new Parent();
    c1.f1();
}

}

public class Child
{
    final int a =100;  // Can't assign a value to final variable
    public static void main(String[] args){
        Child c1=new Child();
        System.out.println(c1.q);
        c1.a=200;
        System.out.println(c1.a);

    }
}
*/

//Static Modifier

/*
public class Parent{
    Static class Inner
    {

    }
    final void f1()
    {
        System.out.println("Hello");
    }
}

public class Parent
{
    Static int a=10;
    Static int b=100;
    Static int c=1000;
    parent p1 = new Parent();
    System.out.pritnln(p1.a);//Accessing static variable with object
        System.out.pritnln(b);//Accessing static variable without object
            System.out.pritnln(parent.c);//Accessing static variable with class
    }

}
*/

//Synchronized Modifier

/*
public class Parent
{
    public Synchronized void f1()
    {
        System.out.println();
        Synchronized(Parent.class)
        {

        }
    }
}

*/

//Strict Floating Point Modifier

/* 
public strictfp class Parent
{
    float f1=244221.1414f;
    public strictfp void print()
    {
        float f2 = 52525.25252f;
        System.out.println(f2);
    }
    public static void main(String[] args)
    {
        Parent p1 =new Parent();
        p1.print();
    }
}
*/

//Abstract Modifier

/*
1)abstract is the modifier we can apply for classes and methods only
2)if a class is declared with abstract modifier  then we cannot create object for that class
3)if a method is declared with abstract modifier then we cannot create body for the method
*/

//Transient Modifier

/* 
1)At the time serialization if we dont want to store tha values of particular variables then
we can declare that variable with transient modifier
2)transient modifier is applicable only for variables but not for classes and methods
*/

//Native modifier:

/*
1)Native is the modifier applicable only for methods but not for classes and variables.
2)For native methods implementation is already available in other languages like c,c++ so
we can call native methods as foregin methods

*/

//Volatile modifier:

/*
1)volatile is the modifier applicable only for variables but not for methods and classes
2)if the value of the variable is changing frequently then such type of variables should be
declared with volatile modifier
3)For Every Thread a seperate local copy will be maintained for volatile variables
4)this modifier is outdated
*/