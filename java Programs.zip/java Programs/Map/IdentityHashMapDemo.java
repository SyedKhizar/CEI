import java.util.*;
public class IdentityHashMapDemo {
    public static void main(String[] args) {
        IdentityHashMap hm=new IdentityHashMap();
   
        Integer i1=new Integer(10);
        Integer i2=new Integer(10);

        hm.put(i1,"Khizar");
        hm.put(i2,"Akram");

        System.out.println(hm);

        System.out.println(i1==i2);
        System.out.println(i1.equals(i2));
    }
}