import java.io.*;
import java.util.*;
public class PropertiesDemo {
    public static void main(String[] args) {
       

Properties p=new Properties();

FileInputStream fis=null;

String username=null;
String password=null;
String url=null;

try {
    fis=new FileInputStream("dbdetails.properties");

    p.load(fis);

     url=p.getProperty("url");
     username=p.getProperty("username");
     password=p.getProperty("password");

   
} catch (Exception e) {
    //TODO: handle exception
    System.out.println(e);
}



System.out.println("Database Driver  URL :"+url);
System.out.println("Database Username:"+username);
System.out.println("Database Password :"+password);

    }
}