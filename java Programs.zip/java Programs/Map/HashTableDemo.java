import java.util.*;
public class HashTableDemo {
    public static void main(String[] args) {
        Hashtable ht=new Hashtable();
        ht.put(1,"Khizar");
        ht.put(true,"Akram");
        ht.put('A',true);
        ht.put(10.3,false);
        ht.put(10.3,1);

        System.out.println(ht);

        System.out.println("Size of HashTable :"+ht.size());
    }
   
}