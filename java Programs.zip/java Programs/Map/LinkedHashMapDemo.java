import java.util.*;
public class LinkedHashMapDemo
{

    public static void main(String[] args) {

        LinkedHashMap hm=new LinkedHashMap();

        hm.put(1,"Prudhvi");
        hm.put(2,"Raj");
        hm.put(null,"ABC");
        hm.put(10.5,100);
        hm.put(true,"xyz");
        hm.put(true,"pRAVEEN");

        System.out.println(hm);
        System.out.println("Size of LinkedHashMap is :"+hm.size());
        System.out.println("Is LinkedHashMap object Empty?"+hm.isEmpty());
        // hm.clear();
        // System.out.println("Is HashMap object Empty?"+hm.isEmpty());

        System.out.println("Value for Key 1 is :"+hm.get(1));

        hm.remove(null);
        System.out.println(hm);

        System.out.println("LinkedHashMap object contains key 10.5 ? "+hm.containsKey(10.5));
        System.out.println("LinkedHashMap object contains Value pRAVEEN ? "+hm.containsValue("PRAVEEN"));

       Collection c1= hm.values();

       System.out.println("Printing Only Values :"+c1);

       Iterator iterator=c1.iterator();

       System.out.println("Printing Only Values");
       while(iterator.hasNext())
       {
           System.out.println(iterator.next());
       }

       Set s1=hm.keySet();

       System.out.println("Printing Only Keys :"+s1);

       
    }
   
}