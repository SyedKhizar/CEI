import java.util.*;
class WeakHashMapDemo
{
    public static void main(String[] args) {
       

        Employee e1=new Employee();

        WeakHashMap hm=new WeakHashMap();

        hm.put(e1,"employee-1");

        System.out.println(hm);

        e1=null;

        System.gc();

        System.out.println(hm);
       }
}