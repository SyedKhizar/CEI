import java.util.*;
public class TreeSetMapDemo {

    public static void main(String[] args) {
       

        TreeMap tm1=new TreeMap();

        tm1.put(5,"Akram");
        tm1.put(3,"Syed");
        tm1.put(2,"Khizar");
        tm1.put(4,"Khizaraa");
        tm1.put(1,"Davood");
     

        System.out.println(tm1);

        TreeMap tm2=new TreeMap();

        tm2.put('Z',1);
        tm2.put('A',2);
        tm2.put('a',3);
        tm2.put('B',4);
        tm2.put('d',null);

        System.out.println(tm2);
    }
   
}