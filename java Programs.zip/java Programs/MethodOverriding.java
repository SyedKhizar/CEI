public class Parent
{

    void eat()
    {
        System.out.println("Eat Rice");
    }
   
}



public class Child extends Parent
{
    void eat()
    {
        System.out.println("No I will eat fruits");
    }

    public static void main(String[] args) {
        Child c1=new Child();
        c1.eat();
    }
}