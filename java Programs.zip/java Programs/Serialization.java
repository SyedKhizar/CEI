/*
public class Employee implements java.io.Serializable
{
    int eid;
    String ename;
    transient String email;

    Employee(int eid,String ename,String email)
    {
        this.eid=eid;
        this.ename=ename;
        this.email=email;
    }
   
}
*/


import java.io.*;
public class Serialization
{
    public static void main(String[] args)throws Exception
     {
        Employee e1=new Employee(1,"khizar","khizar@gmail.com");
        File f=new File("employee.txt");
        FileOutputStream fos=new FileOutputStream(f);
        ObjectOutputStream oos=new ObjectOutputStream(fos);

        oos.writeObject(e1);

        System.out.println("Employee object Serialized");


    }
}