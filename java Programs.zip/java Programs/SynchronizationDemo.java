class Display
{
    public  void wish(String name)
    {

        synchronized(this)
        {
            for(int i=1;i<=5;i++)
            {
                System.out.print("Good Morning :");
                try {
                    Thread.sleep(1000);
                 
                } catch (Exception e) {
                    //TODO: handle exception
                    System.out.println(e);
                }
                System.out.println(name);
            }
        }
       
        System.out.println("Rest of the code");
       
    }

}

class MyThread extends Thread
{
    Display d1;
    String name;
    MyThread(Display d1,String name)
    {
        this.d1=d1;
        this.name=name;
    }

    public void run()
    {
        d1.wish(name);
    }

}

public class SynnchronizationDemo {
    public static void main(String[] args) {

        Display d1=new Display();
     

        MyThread t1=new MyThread(d1,"Khizar");
        MyThread t2=new MyThread(d1,"Akram");
     
       
        t1.start();
        t2.start();
       
    }
   
}