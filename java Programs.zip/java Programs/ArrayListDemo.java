import java.util.*;

class Employee
{
    private int eid;
    private String ename;
    private String ecity;


    Employee(int eid,String ename,String ecity)
    {
        this.eid=eid;
        this.ename=ename;
        this.ecity=ecity;
    }

    //setter methods and getter methods

    public void setEid(int eid)//setter method for eid
    {
        this.eid=eid;
    }

    public int getEid()//getter method for eid
    {
        return eid;
    }
                                         
    public void setEname(String ename)//setter method of ename
    {
        this.ename=ename;
    }

    public String getEname()//getter method for ename
    {
        return ename;
    }

    public void setEcity(String ecity)//setter method for ecity
    {
        this.ecity = ecity;
    }

    public String getEcity() //getter method for ecity
    {
        return ecity;
    }

    public static void main(String[] args) {
        // Employee e1=new Employee();

        // // e1.eid=1;
        // // e1.ename="Prudhvi";
        // // e1.ecity="Bangalore";

        // // System.out.println(e1.eid);
        // // System.out.println(e1.ename);
        // // System.out.println(e1.ecity);

        // e1.setEid(1);
        // e1.setEname("Prudhvi");
        // e1.setEcity("Bangalore");

        // System.out.println(e1.getEid());
        // System.out.println(e1.getEname());
        // System.out.println(e1.getEcity());

    }


}

public class ArrayListDemo {

    public static void main(String[] args) {
        ArrayList al=new ArrayList();
     
        Employee e1=new Employee(1,"Prudhvi","Bangalore");
        Employee e2=new Employee(2,"Kiran","Goa");
        Employee e3=new Employee(3,"Ajay","Hyderabad");
        Employee e4=new Employee(4,"Praveen","Bangalore");
       
        al.add(e1);
        al.add(e2);
        al.add(e3);
        al.add(e4);

        System.out.println(al);

        Iterator iterator=al.iterator();

        while(iterator.hasNext())
        {
            Employee employee=(Employee)iterator.next();
            System.out.println("Employee ID :"+employee.getEid());
            System.out.println("Employee Name :"+employee.getEname());
            System.out.println("Employee City :"+employee.getEcity());
            System.out.println("---------------------------------------------------------------");
        }

    }
   
}