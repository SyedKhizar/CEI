import java.util.*;
class LinkedHashSetDemo
{
    public static void main(String[] args) {
       
        LinkedHashSet hs=new LinkedHashSet();

        hs.add(1);
        hs.add("Khizar");
        hs.add("Akram");
        hs.add(10.141);
        hs.add(true);
        hs.add(null);
        hs.add("Khizar");

        System.out.println(hs);

        System.out.println("Size of LinkedHashSet object is :"+hs.size());

        hs.remove("Khizar");

        System.out.println("After Removing Object Prudhvi From LinkedHashSet Remaining HashSet is :"+hs);

        System.out.println("*****************************************************************************");

        System.out.println("Printing Object of LinkedHashSet one by one using LinkedHashSet object");

        Iterator iterator=hs.iterator();
        while(iterator.hasNext())
        {
            System.out.println(iterator.next());
        }


        // hs.clear();
        // System.out.println("After Removing All Elements from HashSet remaining HashSet is :"+hs);



    }
}