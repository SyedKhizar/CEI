import java.util.*;
class HashSetDemo
{
    public static void main(String[] args) {
       
        HashSet hs=new HashSet();

        hs.add(1);
        hs.add("Khizar");
        hs.add("Akram");
        hs.add(10.141);
        hs.add(true);
        hs.add(null);
        hs.add("Khizar");

        System.out.println(hs);

        System.out.println("Size of HashSet object is :"+hs.size());

        hs.remove("Prudhvi");

        System.out.println("After Removing Object Prudhvo From HashSet Remaining HashSet is :"+hs);

        System.out.println("*****************************************************************************");

        System.out.println("Printing Object of HashSet one by one using HashSet object");

        Iterator iterator=hs.iterator();
        while(iterator.hasNext())
        {
            System.out.println(iterator.next());
        }


        // hs.clear();
        // System.out.println("After Removing All Elements from HashSet remaining HashSet is :"+hs);



    }
}

