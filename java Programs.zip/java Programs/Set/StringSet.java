import java.util.*;
public class StringSet {
   
{
    public static void main(String[] args) {
       
      //  MyComparator mc=new MyComparator();
        TreeSet ts=new TreeSet();

        ts.add("khizar");
        ts.add("akram");
        ts.add("syed");
        ts.add("davood");
        ts.add("nabeel");

        System.out.println(ts);
       // System.out.println(ts.comparator());

    }
}
   
}