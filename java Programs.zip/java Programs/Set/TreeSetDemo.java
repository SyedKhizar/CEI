import java.util.*;

import jdk.nashorn.api.tree.Tree;
public class TreeSetDemo1 {

    public static void main(String[] args) {

        TreeSet ts1=new TreeSet();

        ts1.add("A");
        ts1.add("Z");
        ts1.add("F");
        ts1.add("B");
        ts1.add("C");
        ts1.add("K");


             
        System.out.println(ts1);


        System.out.println("First Element in TreeSet is :"+ts1.first());//A
        System.out.println("Last Element in TreeSet is :"+ts1.last());//Z
        System.out.println(ts1.headSet("F"));
        System.out.println(ts1.tailSet("F"));

        System.out.println(ts1.subSet("B", "Z"));
        System.out.println(ts1.comparator());
       
        TreeSet ts2=new TreeSet();

        ts2.add('A');
        ts2.add('Z');
        ts2.add('H');
        ts2.add('I');

        System.out.println(ts2);
   

    }
   
}