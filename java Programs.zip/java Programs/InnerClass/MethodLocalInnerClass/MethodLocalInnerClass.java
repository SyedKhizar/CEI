public class MethodLocalInnerClass
{

    public static void f1()
    { //start of method
            class Inner
            { //start of the inner class
                public void sum(int a,int b)
                {
                    int c=a+b;
                    System.out.println("Sum is :"+c);
                }
            }//end of inner class

            Inner i1=new Inner();
            i1.sum(10,10);
    }//end of the method

    public static void main(String[] args)
    {

        // MethodLocalInnerClass obj1=new MethodLocalInnerClass();
        MethodLocalInnerClass.f1();
       
    }
   
}