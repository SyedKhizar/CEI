
public class Demo3 {

    public static void main(String[] args) {

        Thread t1=new Thread(new Runnable()
            {
              public void run()
              {
                  for (int i = 0; i < 5; i++)
                  {
                      System.out.println("Child Thread :"+i);
                  }
              }  
            });
           
            t1.start();
       
            for (int i = 0; i < 5; i++)
            {
                System.out.println("Parent Thread :"+i);
            }
    }

   
}