
/*
1)Take a class extending Thread Class
2)Take a class Implementing  Runnable Interface
*/


   

class Demo1
{
    public static void main(String[] args) {

      Thread t1=new Thread()
      { //start of body

        public void run()
        {
            for (int i = 0; i < 5; i++) {
                System.out.println("child thread :"+i);
            }
           
        }

      };//end of the body


      t1.start();

        for (int i = 0; i < 5; i++) {
            System.out.println("Parent Thread :"+i);
        }
       
    }
}