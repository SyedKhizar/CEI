/*
1)Take a class extending Thread Class
2)Take a class Implementing  Runnable Interface
*/



class Demo2
{
    public static void main(String[] args) {

      Runnable r1=new Runnable()
      {
        public void run()
        {
        for (int i = 0; i < 5; i++) {
            System.out.println("Child Thread :"+i);
        }
    }
      };

    Thread t1=new Thread(r1);
    t1.start();
     
        for (int i = 0; i < 5; i++) {
            System.out.println("Parent Thread :"+i);
        }
       
    }
}