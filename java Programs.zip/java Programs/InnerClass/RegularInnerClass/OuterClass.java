
public class OuterDemo
{

    //OuterDemo.class
    //OuterDemo$InnerDemo.class
    int x=10; //instance variable
    static int y=20; //static variable
    class InnerDemo
    { //start of inner class

        static int a=100;//static variable

        void f1()
        {
            System.out.println("Value of x is :"+x);
            System.out.println("Value of y is :"+y);
            System.out.println("Inner Class f1() method");
        }

    } //end of inner class

    public void f2()
    {
        System.out.println("Outer class f2() method");
        InnerDemo i1=new InnerDemo();
        i1.f1();
    }

    public static void main(String[] args)
    {
       

        // OuterDemo o1=new OuterDemo();
        // InnerDemo i1=o1.new InnerDemo();
        // i1.f1();


        OuterDemo o2=new OuterDemo();
        o2.f2();

    }
   
}