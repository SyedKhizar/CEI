public class Demo4
{
    //Demo4.class
    //Demo4$Inner.class
    int a=90;
    static int b=100;
    static class Inner
    {
        public static void f1()
        {
           System.out.println("Value of b is :"+b);
        }
        public static void main(String[] args) {
            System.out.println("main() method from inner class");
        }
    }

    public static void main(String[] args)
    {
       System.out.println("main() method from outer class Demo4");
          Inner.f1();
       
    }
   
}