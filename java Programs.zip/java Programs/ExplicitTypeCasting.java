public class ExplicitTYpeCasting
{

    public static void main(String[] args) {
       

        long l=111222333;

        int i=(int)l;

        float d1=l;

        System.out.println(d1);


        double d2=900.123;

        int i1=(int)d2;

        System.out.println(i1);


    }
   
}