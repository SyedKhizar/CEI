public class Instance
{

    int a;

    {
        a=90;
        System.out.println("Welcome to Instance Block-1");
    }

    {
        System.out.println("Welcome to Instance Block-2");
    }

    {
        System.out.println("Welcome to Instance Block-3");
    }


    public static void main(String[] args) {

        System.out.println("Welcome to main method");
       
        Instance d1=new Instance();
        Instance d2=new Instance();

        System.out.println(d1.a);
    }
   
}