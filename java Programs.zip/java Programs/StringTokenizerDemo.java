import java.util.*;
public class StringTokenizerDemo
{
   
    public static void main(String[] args) {
       
        String target="welcome to String Tokenizer";

        StringTokenizer st1=new StringTokenizer(target);

        while(st1.hasMoreTokens())
        {
            System.out.println(st1.nextToken());
        }

        System.out.println("******************************************************");

        String dob="31-07-1997";

        StringTokenizer st2=new StringTokenizer(dob,"-");

        while(st2.hasMoreTokens())
        {
            System.out.println(st2.nextToken());
        }
       


    }
}