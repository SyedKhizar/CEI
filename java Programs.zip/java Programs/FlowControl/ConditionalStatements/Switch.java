
import java.util.Scanner;
public class Switch{
public static void main(String[] args) {
    System.out.println("1.Savings Account");
    System.out.println("2.Current Account");
    System.out.println("3.Check Balance");
    System.out.println("4.Cash WithDrawl");
    Scanner sc=new Scanner(System.in);
    System.out.println("Please Select Your Option");
    int choice=sc.nextInt();
    switch (choice) {
        case 1:
        {
        System.out.println("Savings Account Selected");
        break;
        }
        case 2:
        {
        System.out.println("Current Account Selected");
        break;
        }
        case 3:
        {
        System.out.println("Check Balance");
        break;
        }
        case 4:
        {
        System.out.println("Cash Withdrawl");
        break;
        }
        default:
        {
            System.out.println("Invalid Choice,Please Try Again");
        }}}}