import java.util.*;
public class ElseIfLadder {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter First Number:");
        int a=sc.nextInt();
        System.out.print("Enter Second Number:");
        int b=sc.nextInt();
        System.out.print("Enter The Third Number:");
        int c=sc.nextInt();
        if(a>b && a>c)
        {
            System.out.println(a+" is Greater than :"+b +" and "+c);
        }
        else if(b>a && b>c)
        {
            System.out.println(b+" is Greater than :"+a +" and "+c);
        }
        else
        {
            System.out.println(c+" is greater than :"+a+" and "+b);
        }}}