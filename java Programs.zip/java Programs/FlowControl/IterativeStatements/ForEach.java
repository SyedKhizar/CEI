
class ForEach{
public static void main(String[] args) {
int a[] = {1,2,3,4,5};
ArrayList<Integer> al = new ArrayList<Integer>();
for(i=0;i<=5;i++)
{
al.add(i);
for(Integer i1 = al)
{
System.out.println(i1);
}}}