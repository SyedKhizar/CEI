public class DoWhile {
public static void main(String[] args) {
int n = 1;
do {
System.out.println(n + " ");
n=n+1;
}
while (n<=10);
       }}