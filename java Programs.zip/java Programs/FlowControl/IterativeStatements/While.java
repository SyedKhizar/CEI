public class While {
public static void main(String[] args) {
int n =1;
while (n<=10)
{
System.out.println(n+" ");
n=n+1;
}}}