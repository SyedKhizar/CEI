public class A {

    void f1()
    {
        System.out.println("f1() method from Class A");
    }

    void f2()
    {
        System.out.println("f2() method from class A");
    }
   
}


public class B extends A{

    // void f2()
    // {
    //     System.out.println("f2() method from Class B");
    // }

    public static void main(String[] args) {
        B b1=new B();
        b1.f1();
        b1.f2();
    }
   
}



public class C  extends B
{

    void f3()
    {
        System.out.println("f3() method from Class C");
    }

    public static void main(String[] args) {
   
        C c1=new C();
        c1.f1();
        c1.f2();
        c1.f3();
       
   
    }
   
}




public class D extends C{

    void f4()
    {
        System.out.println("f4() method from Class D");
    }

    public static void main(String[] args) {
       
        D d1=new D();
        d1.f1();
        d1.f2();
        d1.f3();
        d1.f4();

    }
   
}