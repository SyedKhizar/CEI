﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TestDemo.Models;

namespace TestDemo
{
    public class HomeController : Controller
    {
        OurDbContext _Context;
        public HomeController(OurDbContext context)
        {
            _Context = context;
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login login)
        {
            var query = (from t in _Context.Login where t.Username==login.Username && t.password==login.password select t).FirstOrDefault();
            if(query!=null)
                            
                return RedirectToAction("Register");
            else
            {
                ViewBag.Message = "Username or password does not exist";
                return View();
            }
        }
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(Login lg)
        {
            if (ModelState.IsValid)
            {
                _Context.Login.Add(lg);
                _Context.SaveChanges();
            }
            else
                throw new Exception();
            return RedirectToAction("Login");
        }
    }
}
