﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;

namespace TestDemo.Models
{
    public class OurDbContext :DbContext
    {
        public OurDbContext(DbContextOptions<OurDbContext> options) : base(options)
        { }
            public DbSet<Login> Login { get; set; }
        
    }
    

    
}
